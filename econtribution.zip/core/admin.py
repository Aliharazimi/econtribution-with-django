from django.contrib import admin
from users.models import ContactUs


admin.site.register(ContactUs)
# Register your models here.
